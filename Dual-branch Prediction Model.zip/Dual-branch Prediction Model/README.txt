# Dual-Branch Hybrid Model for Global Food Inflation Prediction

This repository contains the official implementation of the dual-branch hybrid model architecture designed for multidimensional evaluation and attribution analysis of global food inflation across 93 countries. 

The framework tackles the complex dynamics of food inflation in small-sample regimes (monthly observations) by capturing both temporal inertia and cross-variable causal leading relationships, culminating in an adaptive cross-attention fusion mechanism.

## 🧠 Model Architecture

The model takes a historical sequence of length $L=6$ months as input to predict food inflation over the subsequent $H=2$ months. It comprises three core modules:

### 1. T-Branch: Decomposable Mixing (DM) Network
A lightweight temporal network specifically tailored for the small-sample regime. 
- **Instance Normalization:** Applied strictly to input sequences to mitigate local distribution shifts.
- **Series Decomposition:** Utilizes a moving-average kernel of size 5 to separate historical sequences into trend and seasonal components.
- **DM Blocks:** Each component is mapped by an independent linear layer, summed, and projected into a latent space. Two Decomposable Mixing (DM) blocks are stacked to capture temporal inertia and cyclical regularities.
- *Note:* Multiscale down-sampling and multi-predictor ensembling are deliberately omitted to prevent overfitting on limited monthly observations.

### 2. G-Branch: Multi-View Causal Graph Convolutional Network (MV-CausalGCN)
Constructs asymmetric adjacency matrices from three distinct views to capture external macro-variable shocks:
- **Contemporaneous Co-movement:** Statistical Pearson-like correlation.
- **Lagged Leading:** Causal relationships with a time lag ($\tau=1$ month).
- **Differenced Co-movement:** Differential variations capturing explosive short-term trend shifts.
These three views are adaptively fused via a temperature-scaled `softmax` function. The resulting matrix is sparsified at a 0.1 threshold, augmented with self-loops, and row-normalized by out-degree to preserve the leading direction. The fused matrix is then processed through a 4-layer GCN.

### 3. Adaptive Cross-Attention Fusion
Maps the T-Branch and G-Branch outputs into a shared latent space. A learnable query vector employs scaled dot-product attention to adaptively weight the two outputs, producing the final fused prediction.

## ⚙️ Data Preprocessing & Leakage Prevention

Data processing strictly follows a **partition-before-fitting** principle to eliminate forward information leakage.
- **Imputation:** Multi-dimensional median imputation replaces missing predictive features to avoid distortion from hyperinflationary outliers.
- **Scaling:** Uses `RobustScaler` based on the median ($Q_2$) and interquartile range ($IQR$). All scaling parameters are fitted exclusively on the training set (65%) and blindly applied to the validation (15%) and test (20%) sets.
- **Windowing:** A continuous sliding window with a one-month step size transforms the longitudinal country series into approximately 280 overlapping training instances.

## 🚀 Installation & Dependencies

Ensure you have Python 3.8+ installed. The primary dependencies include:

```bash
pip install torch numpy pandas matplotlib seaborn scikit-learn