"""
Dual-branch model architecture for Global Food Inflation Prediction
Target: Predict food inflation over the next H=2 months using a historical sequence of L=6 months across 93 countries.

Architecture:
T-Branch: Lightweight decomposable mixing network capturing temporal inertia and cyclical regularities.
G-Branch: Multi-view causal graph network extracting leading relationships across exogenous variables.
Fusion: Adaptive cross-attention module synthesizing branch outputs in a shared latent space.
"""
import os
import glob
import warnings
import json
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from sklearn.preprocessing import RobustScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import random

plt.rcParams['font.family'] = 'Arial'
plt.rcParams['axes.unicode_minus'] = False


class Config:
    DATA_DIR = r"D:\桌面\data"
    FILLED_DIR = r"D:\桌面\data_filtered"
    TOP_K_LIST = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20]

    SEQ_LEN = 6 # Look-back window (6 months)
    PRED_LEN = 2 # Prediction horizon (2 months)

    BATCH_SIZE = 8
    EPOCHS = 30
    LR = 5e-4
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    SEED = 2025

    TARGET_COL = "food_inflation"

    TOP_K_FEATURES = None
    EXCLUDE_COLS = ["date", "country", "country_name", "time", "year", "month"]

    TIMEMIXER_D_MODEL = 32
    TIMEMIXER_D_FF = 64
    TIMEMIXER_DROPOUT = 0.1
    TIMEMIXER_E_LAYERS = 2
    TIMEMIXER_DECOMP_METHOD = 'moving_avg'
    TIMEMIXER_MOVING_AVG = 5
    TIMEMIXER_TOP_K = 3

    MVCGCN_HIDDEN_DIM = 32
    MVCGCN_NUM_LAYERS = 4
    MVCGCN_DROPOUT = 0.1
    MVCGCN_USE_RESIDUAL = True
    MVCGCN_GRAPH_THRESHOLD = 0.1 # Adjacency sparsity threshold
    MVCGCN_CAUSAL_LAG = 1 # Temporal lag for causal view

    FUSION_HIDDEN_DIM = 64

    PLOT_LAST_N_SAMPLES = 6

    T_BRANCH_NAME = "T-Branch"
    G_BRANCH_NAME = "G-Branch"

    CRISIS_COUNTRIES = {
        'Romania': {
            'years': [2022, 2023],
            'crisis_label': 'Severe Regional Drought + Spillover of Regional Conflict + Energy & Fertilizer Shock',
            'peak_month': '2023-01',
            'peak_value': 22.41
        },
        'Afghanistan': {
            'years': [2022],
            'crisis_label': 'Geopolitical Transition + Severe Drought + Global Price Contagion',
            'peak_month': '2022-06',
            'peak_value': 25.97
        },
        'Australia': {
            'years': [2022],
            'crisis_label': 'Extreme Climate Disasters + War Directlmpact',
            'peak_month': '2022-12',
            'peak_value': 9.22
        },
        'Canada': {
            'years': [2023],
            'crisis_label': 'Supply Chain Disruption + High Input Costs + Supermarket Margin Debate',
            'peak_month': '2023-01',
            'peak_value': 11.39
        },
        'Chile': {
            'years': [2022],
            'crisis_label': 'Global Energy Crisis',
            'peak_month': '2022-08',
            'peak_value': 21.72
        },
        'Italy': {
            'years': [2022],
            'crisis_label': 'Energy Lag + Severe Drought + Greedfltion',
            'peak_month': '2023-03',
            'peak_value': 13.17
        },
        'Uganda': {
            'years': [2022],
            'crisis_label': 'Instability + Supply Shortage + Currency Devaluation',
            'peak_month': '2022-12',
            'peak_value': 23.06
        },
        'United Kingdom': {
            'years': [2022,2023],
            'crisis_label': 'Brexit Frictions + Energy Shock + Labor Shortages',
            'peak_month': '2023-03',
            'peak_value': 19.12
        },
        'Uzbekistan': {
            'years': [2022, 2023],
            'crisis_label': 'Imported Inflation + Anomalous Cold + Exchange Rate Volatility',
            'peak_month': '2022-09',
            'peak_value': 16.44
        },
        'South Africa': {
            'years': [2022, 2023],
            'crisis_label': 'Energy Crisis (Load Shedding) + Global Supply Shocks + Rand Depreciation',
            'peak_month': '2023-03',
            'peak_value': 14.05
        },
    }


config = Config()


def get_output_dir():
    k = config.TOP_K_FEATURES
    base = r"D:\桌面\result"
    return os.path.join(base, f"TimeMixer_MVCausalGCN_top{k}_origscale_valfusion_fixfusion")


def get_feature_config_path():
    k = config.TOP_K_FEATURES
    return os.path.join(get_output_dir(), f"top{k}_feature_selection_config.json")


def get_feature_config_csv_path():
    k = config.TOP_K_FEATURES
    return os.path.join(get_output_dir(), f"top{k}_feature_selection_config.csv")


def set_seed(seed=config.SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


set_seed()

def calculate_feature_correlation(df: pd.DataFrame, target_col: str, exclude_cols: list):
    df_numeric = df.select_dtypes(include=[np.number])
    cols_to_use = [col for col in df_numeric.columns
                   if col not in exclude_cols and col != target_col]

    if target_col not in df_numeric.columns:
        raise ValueError(f"Target column '{target_col}' not found in dataframe")

    correlations = {}
    for col in cols_to_use:
        try:
            corr = df_numeric[col].corr(df_numeric[target_col])
            if not np.isnan(corr):
                correlations[col] = abs(corr)
        except:
            continue

    corr_series = pd.Series(correlations).sort_values(ascending=False)
    return corr_series


def select_top_k_features(df: pd.DataFrame, target_col: str, top_k: int, exclude_cols: list):
    corr_series = calculate_feature_correlation(df, target_col, exclude_cols)

    if top_k is None or top_k <= 0:
        top_features = corr_series.index.tolist()
    else:
        top_features = corr_series.head(top_k).index.tolist()

    selected_features = [target_col] + [f for f in top_features if f != target_col]
    correlation_scores = corr_series.to_dict()

    return selected_features, correlation_scores


def save_feature_config(feature_config: dict, config_path: str):
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(feature_config, f, indent=4, ensure_ascii=False)
    print(f"Feature configuration saved to: {config_path}")


def save_feature_config_csv(feature_config: dict, csv_path: str):
    csv_data = []
    for country, info in feature_config.items():
        selected_features = info['selected_features']
        correlation_scores = info['correlation_scores']
        for i, feature in enumerate(selected_features):
            if feature == config.TARGET_COL:
                csv_data.append({
                    'country': country, 'rank': 0, 'feature': feature,
                    'correlation': 1.0, 'is_target': 'Yes'
                })
            else:
                csv_data.append({
                    'country': country, 'rank': i, 'feature': feature,
                    'correlation': correlation_scores.get(feature, 0.0), 'is_target': 'No'
                })
    df_csv = pd.DataFrame(csv_data)
    df_csv.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print(f"Feature configuration CSV saved to: {csv_path}")

class TwoBranchAttentionFusion(nn.Module):
    """
        Attention fusion module.
        Uses a learnable query vector with scaled dot-product attention to adaptively weight T-branch and G-branch outputs.
    """
    def __init__(self, pred_len: int, hidden_dim: int = 32):
        super().__init__()
        self.pred_len = pred_len
        self.hidden_dim = hidden_dim
        self.branch_proj_tm  = nn.Linear(pred_len, hidden_dim)
        self.branch_proj_gcn = nn.Linear(pred_len, hidden_dim)
        self.fusion_query = nn.Parameter(torch.randn(1, hidden_dim) * 0.1)
        self.key_proj = nn.Linear(hidden_dim, hidden_dim)
        self.value_proj = nn.Linear(hidden_dim, hidden_dim)
        self.output_proj = nn.Linear(hidden_dim, pred_len)

        self._init_weights()

    def _init_weights(self):
        nn.init.xavier_uniform_(self.branch_proj_tm.weight,  gain=0.5)
        nn.init.xavier_uniform_(self.branch_proj_gcn.weight, gain=0.5)
        nn.init.xavier_uniform_(self.key_proj.weight,   gain=0.5)
        nn.init.xavier_uniform_(self.value_proj.weight,  gain=0.5)
        nn.init.xavier_uniform_(self.output_proj.weight, gain=0.5)
        nn.init.zeros_(self.branch_proj_tm.bias)
        nn.init.zeros_(self.branch_proj_gcn.bias)
        nn.init.zeros_(self.key_proj.bias)
        nn.init.zeros_(self.value_proj.bias)
        nn.init.zeros_(self.output_proj.bias)

    def forward(self, branch_outputs, return_both=False):
        tm_out, gcn_out = branch_outputs
        B = tm_out.shape[0]

        simple_avg = (tm_out + gcn_out) / 2

        h_tm  = self.branch_proj_tm(tm_out)
        h_gcn = self.branch_proj_gcn(gcn_out)
        h_stack = torch.stack([h_tm, h_gcn], dim=1)

        K = self.key_proj(h_stack)
        V = self.value_proj(h_stack)
        Q = self.fusion_query.unsqueeze(0).expand(B, -1, -1)

        d_k = self.hidden_dim ** 0.5
        attn_scores = torch.bmm(Q, K.transpose(-2, -1)) / d_k
        attn_weights = F.softmax(attn_scores, dim=-1)

        attended = torch.bmm(attn_weights, V).squeeze(1)
        attn_fused = self.output_proj(attended)

        branch_weights = attn_weights.squeeze(1)

        if return_both:
            return attn_fused, simple_avg, branch_weights
        return attn_fused


class MovingAvgDecomposition(nn.Module):
    def __init__(self, kernel_size: int):
        super().__init__()
        self.kernel_size = kernel_size
        self.avg = nn.AvgPool1d(kernel_size=kernel_size, stride=1, padding=(kernel_size - 1) // 2)

    def forward(self, x):
        front = x[:, :, 0:1].repeat(1, 1, (self.kernel_size - 1) // 2)
        end = x[:, :, -1:].repeat(1, 1, (self.kernel_size - 1) // 2)
        x = torch.cat([front, x, end], dim=2)
        x = self.avg(x)
        trend = x[:, :, :(x.size(2) - self.kernel_size + 1)]
        return trend


class PastDecomposableMixing(nn.Module):
    """
        Decomposable Mixing block.
        Maps separated trend and seasonal components through independent linear layers and sums them in a latent space.
    """
    def __init__(self, seq_len: int, d_model: int, d_ff: int, dropout: float,
                 decomp_method: str, moving_avg: int, top_k: int):
        super().__init__()
        self.seq_len = seq_len
        self.d_model = d_model
        self.decomp_method = decomp_method
        self.top_k = top_k

        if decomp_method == 'moving_avg':
            self.decomp = MovingAvgDecomposition(moving_avg)
        else:
            self.decomp = None

        self.linear_seasonal = nn.Linear(seq_len, d_ff)
        self.linear_trend = nn.Linear(seq_len, d_ff)
        self.linear_output = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        if self.decomp_method == 'moving_avg':
            seasonal = x - self.decomp(x)
            trend = self.decomp(x)
        else:
            seasonal, trend = x, x

        seasonal = self.linear_seasonal(seasonal)
        trend = self.linear_trend(trend)
        out = self.linear_output(seasonal + trend)
        return self.dropout(out)


class DMPredictor(nn.Module):
    """
        T-branch temporal network.
        Applies instance normalization and a moving-average kernel to separate components.
        Uses stacked Decomposable Mixing blocks without multiscale down-sampling to prevent overfitting.
    """
    def __init__(self, seq_len: int, pred_len: int, channels: int, d_model: int = 64, d_ff: int = 128,
                 e_layers: int = 2, dropout: float = 0.1, decomp_method: str = 'moving_avg',
                 moving_avg: int = 5, top_k: int = 3):
        super().__init__()

        self.seq_len = seq_len
        self.pred_len = pred_len
        self.d_model = d_model

        self.pdm_blocks = nn.ModuleList()
        self.pdm_blocks.append(
            PastDecomposableMixing(seq_len=seq_len, d_model=d_model, d_ff=d_ff, dropout=dropout,
                                   decomp_method=decomp_method, moving_avg=moving_avg, top_k=top_k)
        )
        for i in range(1, e_layers):
            self.pdm_blocks.append(
                PastDecomposableMixing(seq_len=d_model, d_model=d_model, d_ff=d_ff, dropout=dropout,
                                       decomp_method=decomp_method, moving_avg=moving_avg, top_k=top_k)
            )

        self.prediction_head = nn.Linear(d_model, pred_len)

    def forward(self, x):
        B, L, C = x.shape
        x = x.transpose(1, 2)
        means = x.mean(2, keepdim=True).detach()
        x = x - means
        stdev = torch.sqrt(torch.var(x, dim=2, keepdim=True, unbiased=False) + 1e-5)
        x = x / stdev

        for block in self.pdm_blocks:
            x = block(x)

        out = self.prediction_head(x)
        out = out * stdev + means
        out = out[:, 0, :]
        return out


class MultiViewGraphConstructor(nn.Module):
    """
        Graph adjacency constructor.
        Dynamically fuses contemporaneous, lagged, and differenced views via temperature-scaled softmax.
        Applies sparsity threshold and row-normalization to preserve leading directions.
    """
    def __init__(self, num_variables: int, graph_threshold: float = 0.1, causal_lag: int = 1):
        super().__init__()
        self.num_variables = num_variables
        self.graph_threshold = graph_threshold
        self.causal_lag = causal_lag

        self.view_weights = nn.Parameter(torch.ones(3) / 3)
        self.temperature = nn.Parameter(torch.tensor(1.0))

    def compute_correlation_view(self, x: torch.Tensor) -> torch.Tensor:
        B, L, C = x.shape
        x_t = x.transpose(1, 2)
        x_mean = x_t.mean(dim=-1, keepdim=True)
        x_std = x_t.std(dim=-1, keepdim=True) + 1e-8
        x_normalized = (x_t - x_mean) / x_std
        corr_matrix = torch.bmm(x_normalized, x_normalized.transpose(1, 2)) / L
        return torch.abs(corr_matrix)

    def compute_lagged_causal_view(self, x: torch.Tensor) -> torch.Tensor:
        B, L, C = x.shape
        lag = min(self.causal_lag, L - 2)
        if lag < 1:
            return torch.zeros(B, C, C, device=x.device)
        x_past = x[:, :-lag, :]
        x_current = x[:, lag:, :]
        x_past_t = x_past.transpose(1, 2)
        x_current_t = x_current.transpose(1, 2)
        past_mean = x_past_t.mean(dim=-1, keepdim=True)
        past_std = x_past_t.std(dim=-1, keepdim=True) + 1e-8
        x_past_norm = (x_past_t - past_mean) / past_std
        curr_mean = x_current_t.mean(dim=-1, keepdim=True)
        curr_std = x_current_t.std(dim=-1, keepdim=True) + 1e-8
        x_curr_norm = (x_current_t - curr_mean) / curr_std
        seq_len_eff = L - lag
        lagged_corr = torch.bmm(x_curr_norm, x_past_norm.transpose(1, 2)) / seq_len_eff
        return torch.abs(lagged_corr)

    def compute_diff_view(self, x: torch.Tensor) -> torch.Tensor:
        B, L, C = x.shape
        if L < 3:
            return torch.zeros(B, C, C, device=x.device)
        x_diff = x[:, 1:, :] - x[:, :-1, :]
        x_diff_t = x_diff.transpose(1, 2)
        diff_mean = x_diff_t.mean(dim=-1, keepdim=True)
        diff_std = x_diff_t.std(dim=-1, keepdim=True) + 1e-8
        x_diff_norm = (x_diff_t - diff_mean) / diff_std
        diff_corr = torch.bmm(x_diff_norm, x_diff_norm.transpose(1, 2)) / (L - 1)
        return torch.abs(diff_corr)

    def forward(self, x: torch.Tensor) -> tuple:
        B, L, C = x.shape
        adj_corr = self.compute_correlation_view(x)
        adj_lagged = self.compute_lagged_causal_view(x)
        adj_diff = self.compute_diff_view(x)
        temp = torch.clamp(self.temperature, min=0.1, max=10.0)
        weights = F.softmax(self.view_weights / temp, dim=0)
        adj_fused = (weights[0] * adj_corr + weights[1] * adj_lagged + weights[2] * adj_diff)
        adj_sparse = torch.where(adj_fused > self.graph_threshold,
                                 adj_fused, torch.zeros_like(adj_fused))
        identity = torch.eye(C, device=x.device).unsqueeze(0).expand(B, -1, -1)
        adj_with_self = adj_sparse + identity
        degree_out = adj_with_self.sum(dim=-1, keepdim=True) + 1e-8
        adj_normalized = adj_with_self / degree_out
        return adj_normalized, weights.detach(), (adj_corr, adj_lagged, adj_diff)


class AsymmetricGraphConvolution(nn.Module):
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / np.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        support = torch.matmul(x, self.weight)
        output = torch.bmm(adj, support)
        if self.bias is not None:
            output = output + self.bias
        return output


class MVCausalGCNPredictor(nn.Module):
    """
        G-branch graph network.
        Processes the adaptively fused asymmetric adjacency matrix through a 4-layer Graph Convolutional Network.
    """
    def __init__(self, seq_len: int, pred_len: int, channels: int,
                 hidden_dim: int = 64, num_layers: int = 4, dropout: float = 0.1,
                 use_residual: bool = True, graph_threshold: float = 0.1,
                 causal_lag: int = 1):
        super().__init__()

        self.seq_len = seq_len
        self.pred_len = pred_len
        self.channels = channels
        self.hidden_dim = hidden_dim
        self.use_residual = use_residual

        self.graph_constructor = MultiViewGraphConstructor(
            num_variables=channels, graph_threshold=graph_threshold, causal_lag=causal_lag)

        self.temporal_encoder = nn.Sequential(
            nn.Linear(seq_len, hidden_dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim))

        self.gcn_layers = nn.ModuleList()
        self.gcn_norms = nn.ModuleList()
        for i in range(num_layers):
            self.gcn_layers.append(AsymmetricGraphConvolution(hidden_dim, hidden_dim))
            self.gcn_norms.append(nn.LayerNorm(hidden_dim))

        self.dropout = nn.Dropout(dropout)

        self.predictor = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(hidden_dim, pred_len))

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight, gain=0.5)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor):
        B, L, C = x.shape
        adj, view_weights, _ = self.graph_constructor(x)
        x_t = x.transpose(1, 2)
        means = x_t.mean(dim=-1, keepdim=True).detach()
        stdev = torch.sqrt(x_t.var(dim=-1, keepdim=True, unbiased=False) + 1e-5).detach()
        x_normalized = (x_t - means) / stdev
        node_features = self.temporal_encoder(x_normalized)
        h = node_features
        for gcn_layer, norm in zip(self.gcn_layers, self.gcn_norms):
            h_new = gcn_layer(h, adj)
            h_new = F.gelu(h_new)
            h_new = norm(h_new)
            h_new = self.dropout(h_new)
            if self.use_residual:
                h = h + h_new
            else:
                h = h_new
        target_features = h[:, 0, :]
        out = self.predictor(target_features)
        out = out * stdev[:, 0, :] + means[:, 0, :]
        return out

class TwoBranchHybridModel(nn.Module):
    def __init__(self, seq_len: int, pred_len: int, channels: int):
        super().__init__()
        self.seq_len = seq_len
        self.pred_len = pred_len
        self.channels = channels

        self.dm_model = DMPredictor(
            seq_len=seq_len, pred_len=pred_len, channels=channels,
            d_model=config.TIMEMIXER_D_MODEL, d_ff=config.TIMEMIXER_D_FF,
            e_layers=config.TIMEMIXER_E_LAYERS, dropout=config.TIMEMIXER_DROPOUT,
            decomp_method=config.TIMEMIXER_DECOMP_METHOD, moving_avg=config.TIMEMIXER_MOVING_AVG)

        self.mvcgcn_model = MVCausalGCNPredictor(
            seq_len=seq_len, pred_len=pred_len, channels=channels,
            hidden_dim=config.MVCGCN_HIDDEN_DIM, num_layers=config.MVCGCN_NUM_LAYERS,
            dropout=config.MVCGCN_DROPOUT, use_residual=config.MVCGCN_USE_RESIDUAL,
            graph_threshold=config.MVCGCN_GRAPH_THRESHOLD, causal_lag=config.MVCGCN_CAUSAL_LAG)

        self.fusion = TwoBranchAttentionFusion(pred_len=pred_len, hidden_dim=config.FUSION_HIDDEN_DIM)

    def forward(self, x, return_all=False, return_both_fusion=False):
        tm_out = self.dm_model(x)
        gcn_out = self.mvcgcn_model(x)
        branch_outputs = [tm_out, gcn_out]

        if return_both_fusion:
            attn_fused, simple_avg, weights = self.fusion(branch_outputs, return_both=True)
            if return_all:
                return attn_fused, simple_avg, tm_out, gcn_out, weights
            return attn_fused, simple_avg, weights
        else:
            attn_fused = self.fusion(branch_outputs, return_both=False)
            if return_all:
                return attn_fused, tm_out, gcn_out
            return attn_fused

def fill_and_clean_data(df: pd.DataFrame, target_col: str) -> pd.DataFrame:
    df = df.copy()
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    df = df[numeric_cols]
    df.dropna(axis=1, how='all', inplace=True)
    if target_col in df.columns:
        df = df[df[target_col].notna()]
    for col in df.columns:
        if df[col].isna().any():
            df[col].fillna(df[col].median(), inplace=True)
    df.dropna(inplace=True)
    return df


def prepare_data_with_selected_features(df: pd.DataFrame, selected_features: list,
                                        seq_len: int, pred_len: int):
    df_selected = df[selected_features].copy()
    data = df_selected.values.astype(np.float32)
    feat_names = df_selected.columns.tolist()

    n_samples = len(data) - seq_len - pred_len + 1
    if n_samples < 10:
        raise ValueError(f"Not enough data: only {n_samples} samples")

    test_size = min(max(int(0.2 * n_samples), 2), n_samples - 4)
    val_size = min(max(int(0.15 * n_samples), 2), n_samples - test_size - 2)
    train_size = n_samples - val_size - test_size

    train_end = train_size + seq_len + pred_len - 1

    scaler = RobustScaler()
    scaler.fit(data[:train_end])
    data_scaled = scaler.transform(data)

    train_data = data_scaled[:train_end]
    val_data = data_scaled[train_size:train_size + val_size + seq_len + pred_len - 1]
    test_data = data_scaled[train_size + val_size:]

    return train_data, val_data, test_data, scaler, feat_names, train_size, val_size


class TimeSeriesDataset(Dataset):
    def __init__(self, data, seq_len, pred_len):
        self.data = data
        self.seq_len = seq_len
        self.pred_len = pred_len

    def __len__(self):
        return len(self.data) - self.seq_len - self.pred_len + 1

    def __getitem__(self, idx):
        x = self.data[idx:idx + self.seq_len]
        y = self.data[idx + self.seq_len:idx + self.seq_len + self.pred_len, 0]
        return torch.FloatTensor(x), torch.FloatTensor(y)

def extract_date_labels(df_original: pd.DataFrame) -> list:
    df = df_original.copy()
    n = len(df)

    ym_col = next(
        (c for c in df.columns
         if 'year' in str(c).lower() and 'month' in str(c).lower()),
        None
    )
    if ym_col:
        try:
            dates = pd.to_datetime(df[ym_col], errors='coerce')
            if dates.notna().sum() > n * 0.5:
                result = []
                for d in dates:
                    result.append(d.strftime('%Y-%m') if pd.notna(d) else None)
                for i in range(len(result)):
                    if result[i] is None:
                        result[i] = result[i-1] if i > 0 else 'unknown'
                return result
        except Exception:
            pass

    year_col  = next((c for c in df.columns if str(c).strip().lower() == 'year'),  None)
    month_col = next((c for c in df.columns if str(c).strip().lower() == 'month'), None)
    if year_col and month_col:
        labels = []
        ok = 0
        for _, r in df[[year_col, month_col]].iterrows():
            try:
                y, m = r[year_col], r[month_col]
                if pd.isna(y) or pd.isna(m):
                    labels.append(None)
                else:
                    labels.append(f'{int(y)}-{int(m):02d}')
                    ok += 1
            except Exception:
                labels.append(None)
        if ok > n * 0.5:
            for i in range(len(labels)):
                if labels[i] is None:
                    labels[i] = labels[i-1] if i > 0 else 'unknown'
            return labels

    for col in [c for c in df.columns
                if any(k in str(c).lower() for k in ('date', 'time'))]:
        try:
            dates = pd.to_datetime(df[col], errors='coerce')
            if dates.notna().sum() > n * 0.5:
                return [d.strftime('%Y-%m') if pd.notna(d) else 'unknown'
                        for d in dates]
        except Exception:
            pass

    return [str(i) for i in range(n)]

def get_test_date_labels(all_labels: list, train_size: int, val_size: int,
                         seq_len: int, pred_len: int, n_test_samples: int) -> list:
    result = []
    for i in range(n_test_samples):
        idx = train_size + val_size + seq_len + i
        if idx < len(all_labels):
            result.append(all_labels[idx])
        else:
            result.append(f"t{idx}")
    return result

def calculate_all_metrics(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true.flatten(), y_pred.flatten())
    return {'MAE': mae, 'MSE': mse, 'RMSE': rmse, 'R2': r2}

def train_two_branch_hybrid(train_data, val_data, test_data, scaler, feat_names, country):
    seq_len = config.SEQ_LEN
    pred_len = config.PRED_LEN
    channels = len(feat_names)
    device = config.DEVICE

    print(f"Model config: seq_len={seq_len}, pred_len={pred_len}, channels={channels}")

    train_dataset = TimeSeriesDataset(train_data, seq_len, pred_len)
    val_dataset = TimeSeriesDataset(val_data, seq_len, pred_len)
    test_dataset = TimeSeriesDataset(test_data, seq_len, pred_len)

    train_loader = DataLoader(train_dataset, batch_size=config.BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=config.BATCH_SIZE, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=config.BATCH_SIZE, shuffle=False)

    print(f"Training {config.T_BRANCH_NAME} + {config.G_BRANCH_NAME} with Attention Fusion...")

    model = TwoBranchHybridModel(seq_len, pred_len, channels).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=config.LR)
    criterion = nn.MSELoss()

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=3)

    best_val_loss = float('inf')
    patience = 5
    patience_counter = 0
    best_model_state = None

    for epoch in range(config.EPOCHS):
        model.train()
        train_loss_fused = 0.0

        for X_batch, y_batch in train_loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
            optimizer.zero_grad()

            attn_fused, tm_pred, gcn_pred = model(X_batch, return_all=True)
            loss_fused = criterion(attn_fused, y_batch)
            loss_tm = criterion(tm_pred, y_batch)
            loss_gcn = criterion(gcn_pred, y_batch)
            total_loss = loss_fused + 0.2 * (loss_tm + loss_gcn)

            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            train_loss_fused += loss_fused.item()

        train_loss_fused /= len(train_loader)

        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch = X_batch.to(device)
                y_batch = y_batch.to(device)
                attn_fused = model(X_batch)
                loss = criterion(attn_fused, y_batch)
                val_loss += loss.item()

        val_loss /= len(val_loader)
        scheduler.step(val_loss)

        if (epoch + 1) % 5 == 0:
            print(f"    Epoch {epoch + 1}/{config.EPOCHS}: Train={train_loss_fused:.6f}, Val={val_loss:.6f}")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_model_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"    Early stopping at epoch {epoch + 1}")
                break

    if best_model_state is not None:
        model.load_state_dict({k: v.to(device) for k, v in best_model_state.items()})

    print("Making predictions on test set...")
    model.eval()
    all_attn_fused, all_simple_avg = [], []
    all_tm_preds, all_gcn_preds = [], []
    all_weights, all_true = [], []

    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            X_batch = X_batch.to(device)
            attn_fused, simple_avg, tm_pred, gcn_pred, weights = model(
                X_batch, return_all=True, return_both_fusion=True)
            all_attn_fused.append(attn_fused.cpu().numpy())
            all_simple_avg.append(simple_avg.cpu().numpy())
            all_tm_preds.append(tm_pred.cpu().numpy())
            all_gcn_preds.append(gcn_pred.cpu().numpy())
            all_weights.append(weights.cpu().numpy())
            all_true.append(y_batch.numpy())

    attn_fused_preds = np.concatenate(all_attn_fused, axis=0)
    simple_avg_preds = np.concatenate(all_simple_avg, axis=0)
    tm_preds = np.concatenate(all_tm_preds, axis=0)
    gcn_preds = np.concatenate(all_gcn_preds, axis=0)
    fusion_weights = np.concatenate(all_weights, axis=0)
    y_true = np.concatenate(all_true, axis=0)

    avg_weights = fusion_weights.mean(axis=0)

    model.eval()
    val_mse_attn = 0.0
    val_mse_avg = 0.0
    with torch.no_grad():
        for X_batch, y_batch in val_loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
            attn_out, avg_out, _, _, _ = model(
                X_batch, return_all=True, return_both_fusion=True)
            val_mse_attn += criterion(attn_out, y_batch).item()
            val_mse_avg += criterion(avg_out, y_batch).item()
    val_mse_attn /= len(val_loader)
    val_mse_avg /= len(val_loader)

    if val_mse_attn <= val_mse_avg:
        selected_method = "CrossAttention"
        final_preds = attn_fused_preds
        print(f"Selected: Cross-Attention Fusion (val MSE={val_mse_attn:.6f} <= val Avg={val_mse_avg:.6f})")
    else:
        selected_method = "SimpleAverage"
        final_preds = simple_avg_preds
        print(f" Selected: Simple Average (val MSE={val_mse_avg:.6f} < val Attn={val_mse_attn:.6f})")

    print(f"Attention weights: {config.T_BRANCH_NAME}={avg_weights[0]:.3f}, {config.G_BRANCH_NAME}={avg_weights[1]:.3f}")

    def inverse_transform_single(pred, scaler):
        original_shape = pred.shape
        if pred.ndim == 1:
            pred = pred.reshape(-1, 1)
        n_samples, n_steps = pred.shape
        result = np.zeros_like(pred)
        for step in range(n_steps):
            dummy = np.zeros((n_samples, scaler.scale_.shape[0]))
            dummy[:, 0] = pred[:, step]
            inverse_dummy = scaler.inverse_transform(dummy)
            result[:, step] = inverse_dummy[:, 0]
        return result.reshape(original_shape)

    y_true_orig        = inverse_transform_single(y_true, scaler)
    final_preds_orig   = inverse_transform_single(final_preds, scaler)
    attn_fused_orig    = inverse_transform_single(attn_fused_preds, scaler)
    simple_avg_orig    = inverse_transform_single(simple_avg_preds, scaler)
    tm_preds_orig      = inverse_transform_single(tm_preds, scaler)
    gcn_preds_orig     = inverse_transform_single(gcn_preds, scaler)

    metrics_final = calculate_all_metrics(y_true_orig, final_preds_orig)
    metrics_attn  = calculate_all_metrics(y_true_orig, attn_fused_orig)
    metrics_avg   = calculate_all_metrics(y_true_orig, simple_avg_orig)
    metrics_tm    = calculate_all_metrics(y_true_orig, tm_preds_orig)
    metrics_gcn   = calculate_all_metrics(y_true_orig, gcn_preds_orig)

    print(f"[orig-scale] Final MAE={metrics_final['MAE']:.4f}pp, "
          f"RMSE={metrics_final['RMSE']:.4f}pp, R²={metrics_final['R2']:.4f}")

    results = {
        "predictions": final_preds_orig,
        "attn_fused_predictions": attn_fused_orig,
        "simple_avg_predictions": simple_avg_orig,
        "timemixer_predictions": tm_preds_orig,
        "gcn_predictions": gcn_preds_orig,
        "true_values": y_true_orig,
        "selected_method": selected_method,
        "metrics": {
            "MAE": metrics_final['MAE'], "MSE": metrics_final['MSE'],
            "RMSE": metrics_final['RMSE'], "R2": metrics_final['R2'],
            "MAE_CrossAttn": metrics_attn['MAE'], "MSE_CrossAttn": metrics_attn['MSE'],
            "RMSE_CrossAttn": metrics_attn['RMSE'], "R2_CrossAttn": metrics_attn['R2'],
            "MAE_SimpleAvg": metrics_avg['MAE'], "MSE_SimpleAvg": metrics_avg['MSE'],
            "RMSE_SimpleAvg": metrics_avg['RMSE'], "R2_SimpleAvg": metrics_avg['R2'],
            "MAE_TimeMixer": metrics_tm['MAE'], "MSE_TimeMixer": metrics_tm['MSE'],
            "RMSE_TimeMixer": metrics_tm['RMSE'], "R2_TimeMixer": metrics_tm['R2'],
            "MAE_GCN": metrics_gcn['MAE'], "MSE_GCN": metrics_gcn['MSE'],
            "RMSE_GCN": metrics_gcn['RMSE'], "R2_GCN": metrics_gcn['R2'],
            "weight_timemixer": float(avg_weights[0]),
            "weight_gcn": float(avg_weights[1]),
        }
    }

    return model, results

def _format_x_axis(ax, date_labels: list, max_ticks: int = 16):
    n = len(date_labels)
    if n == 0:
        return

    step = max(1, n // max_ticks)
    tick_positions = list(range(0, n, step))
    tick_labels = [date_labels[i] for i in tick_positions]

    ax.set_xticks(tick_positions)
    ax.set_xticklabels(tick_labels, rotation=45, ha='right', fontsize=8)
    ax.set_xlabel('Month', fontsize=12)


def _file_prefix(country: str) -> str:
    k = config.TOP_K_FEATURES
    return f"{country}_top{k}"


def _get_plots_dir(country: str, output_dir: str) -> str:
    if country in config.CRISIS_COUNTRIES:
        d = os.path.join(output_dir, "plots", "crisis_countries", country)
    else:
        d = os.path.join(output_dir, "plots")
    os.makedirs(d, exist_ok=True)
    return d

def plot_predictions(results, country, output_dir, date_labels):
    n_samples = len(results["true_values"])
    x_range = range(n_samples)
    labels = date_labels[-n_samples:] if len(date_labels) >= n_samples else date_labels

    fig, axes = plt.subplots(config.PRED_LEN, 1, figsize=(14, 5 * config.PRED_LEN))
    if config.PRED_LEN == 1:
        axes = [axes]

    colors = {'True': 'black', 'Fused': 'red', 'T-Branch': 'blue', 'G-Branch': 'green', 'SimpleAvg': 'orange'}
    markers = {'True': 'o', 'Fused': 's', 'T-Branch': '^', 'G-Branch': 'v', 'SimpleAvg': 'd'}

    for h, ax in enumerate(axes):
        ax.plot(x_range, results["true_values"][:, h], color=colors['True'],
                marker=markers['True'], markersize=4, linewidth=1.5, label='True')
        ax.plot(x_range, results["predictions"][:, h], color=colors['Fused'],
                marker=markers['Fused'], markersize=4, linewidth=1.5, label='Fused')
        ax.plot(x_range, results["timemixer_predictions"][:, h], color=colors['T-Branch'],
                marker=markers['T-Branch'], markersize=4, linewidth=1.5, label=config.T_BRANCH_NAME)
        ax.plot(x_range, results["gcn_predictions"][:, h], color=colors['G-Branch'],
                marker=markers['G-Branch'], markersize=4, linewidth=1.5, label=config.G_BRANCH_NAME)
        ax.plot(x_range, results["simple_avg_predictions"][:, h], color=colors['SimpleAvg'],
                marker=markers['SimpleAvg'], markersize=4, linewidth=1.5, label='SimpleAvg')

        ax.set_title(f'{country} — Prediction Step t+{h + 1} (Top{config.TOP_K_FEATURES} Features)',
                     fontsize=14, fontweight='bold')
        _format_x_axis(ax, labels)
        ax.set_ylabel('Food Inflation Rate (%)', fontsize=12)
        ax.legend(loc='upper right', fontsize=10)
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plots_dir = _get_plots_dir(country, output_dir)
    fname = f"{_file_prefix(country)}_predictions.png"
    plt.savefig(os.path.join(plots_dir, fname), dpi=150, bbox_inches='tight')
    plt.close()


def plot_last_n_detailed(results, country, output_dir, date_labels):
    n = config.PLOT_LAST_N_SAMPLES
    true_vals = results["true_values"][-n:]
    fused_vals = results["predictions"][-n:]
    tm_vals = results["timemixer_predictions"][-n:]
    gcn_vals = results["gcn_predictions"][-n:]
    avg_vals = results["simple_avg_predictions"][-n:]

    labels_last = date_labels[-n:] if len(date_labels) >= n else date_labels

    fig = plt.figure(figsize=(14, 12))

    ax1 = fig.add_subplot(3, 1, 1)
    x = np.arange(n)
    width = 0.15
    colors_t1 = ['black', 'red', 'blue', 'green', 'orange']
    colors_t2 = ['gray', 'darkred', 'darkblue', 'darkgreen', 'darkorange']

    for h in range(config.PRED_LEN):
        offset = h * 0.4
        alpha = 1.0 if h == 0 else 0.7
        ct = colors_t1 if h == 0 else colors_t2
        ax1.bar(x + offset - 2 * width, true_vals[:, h], width, label=f'True t+{h+1}', color=ct[0], alpha=alpha)
        ax1.bar(x + offset - width, fused_vals[:, h], width, label=f'Fused t+{h+1}', color=ct[1], alpha=alpha)
        ax1.bar(x + offset, tm_vals[:, h], width, label=f'{config.T_BRANCH_NAME} t+{h+1}', color=ct[2], alpha=alpha)
        ax1.bar(x + offset + width, gcn_vals[:, h], width, label=f'{config.G_BRANCH_NAME} t+{h+1}', color=ct[3], alpha=alpha)
        ax1.bar(x + offset + 2 * width, avg_vals[:, h], width, label=f'Avg t+{h+1}', color=ct[4], alpha=alpha)

    ax1.set_xticks(x + 0.2)
    ax1.set_xticklabels(labels_last, rotation=45, ha='right', fontsize=9)
    ax1.set_xlabel('Month', fontsize=11)
    ax1.set_ylabel('Food Inflation Rate (%)', fontsize=11)
    ax1.set_title(f'{country} — Last {n} Samples Detail (Top{config.TOP_K_FEATURES})',
                  fontsize=14, fontweight='bold')
    ax1.legend(loc='upper left', fontsize=8, ncol=5)
    ax1.grid(True, alpha=0.3, axis='y')
    ax2 = fig.add_subplot(3, 1, 2)
    width2 = 0.12
    for h in range(config.PRED_LEN):
        offset = h * 0.35
        alpha = 1.0 if h == 0 else 0.7
        ct = colors_t1 if h == 0 else colors_t2
        ef = np.abs(fused_vals[:, h] - true_vals[:, h])
        et = np.abs(tm_vals[:, h] - true_vals[:, h])
        eg = np.abs(gcn_vals[:, h] - true_vals[:, h])
        ea = np.abs(avg_vals[:, h] - true_vals[:, h])
        ax2.bar(x + offset - 1.5 * width2, ef, width2, label=f'Fused t+{h+1}', color=ct[1], alpha=alpha)
        ax2.bar(x + offset - 0.5 * width2, et, width2, label=f'{config.T_BRANCH_NAME} t+{h+1}', color=ct[2], alpha=alpha)
        ax2.bar(x + offset + 0.5 * width2, eg, width2, label=f'{config.G_BRANCH_NAME} t+{h+1}', color=ct[3], alpha=alpha)
        ax2.bar(x + offset + 1.5 * width2, ea, width2, label=f'Avg t+{h+1}', color=ct[4], alpha=alpha)

    ax2.set_xticks(x + 0.175)
    ax2.set_xticklabels(labels_last, rotation=45, ha='right', fontsize=9)
    ax2.set_xlabel('Month', fontsize=11)
    ax2.set_ylabel('Absolute Error', fontsize=11)
    ax2.set_title('Error Comparison', fontsize=14, fontweight='bold')
    ax2.legend(loc='upper right', fontsize=8, ncol=4)
    ax2.grid(True, alpha=0.3, axis='y')
    ax3 = fig.add_subplot(3, 1, 3)
    ax3.axis('off')
    metrics = results["metrics"]
    table_data = [
        ['Fused', f'{metrics["MAE"]:.3f}', f'{metrics["MSE"]:.3f}', f'{metrics["RMSE"]:.3f}', f'{metrics["R2"]:.3f}'],
        [config.T_BRANCH_NAME, f'{metrics["MAE_TimeMixer"]:.3f}', f'{metrics["MSE_TimeMixer"]:.3f}',
         f'{metrics["RMSE_TimeMixer"]:.3f}', f'{metrics["R2_TimeMixer"]:.3f}'],
        [config.G_BRANCH_NAME, f'{metrics["MAE_GCN"]:.3f}', f'{metrics["MSE_GCN"]:.3f}',
         f'{metrics["RMSE_GCN"]:.3f}', f'{metrics["R2_GCN"]:.3f}'],
        ['SimpleAverage', f'{metrics["MAE_SimpleAvg"]:.3f}', f'{metrics["MSE_SimpleAvg"]:.3f}',
         f'{metrics["RMSE_SimpleAvg"]:.3f}', f'{metrics["R2_SimpleAvg"]:.3f}'],
    ]
    col_labels = ['Model', 'MAE', 'MSE', 'RMSE', 'R²']
    table = ax3.table(cellText=table_data, colLabels=col_labels, loc='center', cellLoc='center')
    table.auto_set_font_size(False)
    table.set_fontsize(11)
    table.scale(1.2, 1.8)
    for j in range(len(col_labels)):
        cell = table[(0, j)]
        cell.set_facecolor('#4CAF50')
        cell.set_text_props(color='white', fontweight='bold')
    for i in range(1, len(table_data) + 1):
        table[(i, 0)].set_facecolor('#E8F5E9')
    mae_values = [metrics["MAE"], metrics["MAE_TimeMixer"], metrics["MAE_GCN"], metrics["MAE_SimpleAvg"]]
    table[(np.argmin(mae_values) + 1, 1)].set_facecolor('#FFEB3B')

    plt.tight_layout()
    fname = f"{_file_prefix(country)}_last{n}_detailed.png"
    plt.savefig(os.path.join(_get_plots_dir(country, output_dir), fname), dpi=150, bbox_inches='tight')
    plt.close()


def plot_timeline_comparison(results, country, output_dir, date_labels):
    metrics = results["metrics"]
    true_vals = results["true_values"][:, 0]
    pred_vals = results["predictions"][:, 0]
    n_samples = len(true_vals)
    x_range = np.arange(n_samples)
    labels = date_labels[-n_samples:] if len(date_labels) >= n_samples else date_labels

    fig, ax = plt.subplots(figsize=(16, 6))
    ax.fill_between(x_range, true_vals, pred_vals, alpha=0.3, color='gray', label='Prediction Error')
    ax.plot(x_range, true_vals, color='black', marker='o', markersize=5, linewidth=1.5, label='True Value')
    ax.plot(x_range, pred_vals, color='red', marker='s', markersize=5, linewidth=1.5, label='Fused Prediction')

    ax.set_title(
        f'{country} — Timeline Comparison (MAE={metrics["MAE"]:.3f}, R²={metrics["R2"]:.3f})'
        f'  |  Top{config.TOP_K_FEATURES} Features',
        fontsize=13, fontweight='bold')
    _format_x_axis(ax, labels)
    ax.set_ylabel('Food Inflation Rate (%)', fontsize=12)
    ax.legend(loc='upper right', fontsize=11)
    ax.grid(True, alpha=0.3, linestyle='--')

    plt.tight_layout()
    fname = f"{_file_prefix(country)}_timeline.png"
    plt.savefig(os.path.join(_get_plots_dir(country, output_dir), fname), dpi=150, bbox_inches='tight')
    plt.close()


def plot_two_branch_results(results, country, output_dir, date_labels):
    n_samples = len(results["true_values"])
    labels = date_labels[-n_samples:] if len(date_labels) >= n_samples else date_labels

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    for h, ax in enumerate(axes.flatten()[:config.PRED_LEN]):
        ax.plot(range(n_samples), results["true_values"][:, h], 'k-', label='True', linewidth=2)
        ax.plot(range(n_samples), results["predictions"][:, h], 'r--', label='Final Pred', linewidth=1.5)
        ax.plot(range(n_samples), results["timemixer_predictions"][:, h], 'b:', label=config.T_BRANCH_NAME, alpha=0.7)
        ax.plot(range(n_samples), results["gcn_predictions"][:, h], 'g:', label=config.G_BRANCH_NAME, alpha=0.7)
        ax.set_title(f'{country} — Horizon {h + 1}', fontsize=12)
        _format_x_axis(ax, labels)
        ax.set_ylabel('Food Inflation Rate (%)', fontsize=10)
        ax.legend(loc='upper right', fontsize=8)
        ax.grid(True, alpha=0.3)
    for ax in axes.flatten()[config.PRED_LEN:]:
        ax.axis('off')

    plt.tight_layout()
    fname = f"{_file_prefix(country)}_branches.png"
    plt.savefig(os.path.join(_get_plots_dir(country, output_dir), fname), dpi=150)
    plt.close()


def plot_fusion_comparison(results, country, output_dir, date_labels):
    n_samples = len(results["true_values"])
    labels = date_labels[-n_samples:] if len(date_labels) >= n_samples else date_labels

    fig, axes = plt.subplots(1, config.PRED_LEN, figsize=(12, 4))
    if config.PRED_LEN == 1:
        axes = [axes]
    for h, ax in enumerate(axes):
        ax.plot(range(n_samples), results["true_values"][:, h], 'k-', label='True', linewidth=2)
        ax.plot(range(n_samples), results["attn_fused_predictions"][:, h], 'r--', label='CrossAttn', linewidth=1.5)
        ax.plot(range(n_samples), results["simple_avg_predictions"][:, h], 'b:', label='SimpleAvg', linewidth=1.5)
        ax.set_title(f'{country} — Fusion H{h + 1}', fontsize=11)
        _format_x_axis(ax, labels)
        ax.set_ylabel('Food Inflation Rate (%)', fontsize=10)
        ax.legend(loc='upper right', fontsize=8)
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    fname = f"{_file_prefix(country)}_fusion.png"
    plt.savefig(os.path.join(_get_plots_dir(country, output_dir), fname), dpi=150)
    plt.close()


def plot_last_samples(results, country, output_dir, date_labels):
    n = config.PLOT_LAST_N_SAMPLES
    true_vals = results["true_values"][-n:]
    pred_vals = results["predictions"][-n:]
    labels_last = date_labels[-n:] if len(date_labels) >= n else date_labels

    fig, ax = plt.subplots(figsize=(10, 5))
    x = np.arange(n)
    width = 0.35
    for h in range(config.PRED_LEN):
        ax.bar(x - width / 2 + h * width / config.PRED_LEN, true_vals[:, h],
               width / config.PRED_LEN, label=f'True H{h + 1}', alpha=0.7)
        ax.bar(x + width / 2 + h * width / config.PRED_LEN, pred_vals[:, h],
               width / config.PRED_LEN, label=f'Pred H{h + 1}', alpha=0.7)

    ax.set_xticks(x)
    ax.set_xticklabels(labels_last, rotation=45, ha='right', fontsize=9)
    ax.set_xlabel('Month', fontsize=11)
    ax.set_ylabel('Food Inflation Rate (%)', fontsize=11)
    ax.set_title(f'{country} — Last {n} Test Samples (Top{config.TOP_K_FEATURES})', fontsize=12)
    ax.legend()
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    fname = f"{_file_prefix(country)}_last_samples.png"
    plt.savefig(os.path.join(_get_plots_dir(country, output_dir), fname), dpi=150)
    plt.close()

def plot_crisis_analysis(results, country, output_dir, date_labels, crisis_info):
    n_samples = len(results["true_values"])
    labels = date_labels[-n_samples:] if len(date_labels) >= n_samples else date_labels
    crisis_years = crisis_info['years']
    crisis_indices = []
    for i, lbl in enumerate(labels):
        try:
            year_str = lbl.split('-')[0]
            if int(year_str) in crisis_years:
                crisis_indices.append(i)
        except Exception:
            continue

    if len(crisis_indices) < 2:
        print(f"Crisis plot skipped for {country}: not enough crisis-period samples in test set")
        return

    ci = np.array(crisis_indices)
    c_labels = [labels[i] for i in ci]
    c_true = results["true_values"][ci]
    c_fused = results["predictions"][ci]
    c_tm = results["timemixer_predictions"][ci]
    c_gcn = results["gcn_predictions"][ci]
    c_avg = results["simple_avg_predictions"][ci]

    x = np.arange(len(ci))

    col_true = 'black'
    col_fused = '#D32F2F'
    col_tm = '#1565C0'
    col_gcn = '#2E7D32'
    col_avg = '#E65100'

    fig = plt.figure(figsize=(16, 14))
    fig.suptitle(
        f'{country} — Food Inflation Crisis Analysis\n'
        f'Crisis Period: {", ".join(str(y) for y in crisis_years)}  |  '
        f'{crisis_info["crisis_label"]}\n'
        f'Peak: {crisis_info["peak_month"]} (~{crisis_info["peak_value"]}%)  |  '
        f'Top{config.TOP_K_FEATURES} Features',
        fontsize=13, fontweight='bold', y=0.98
    )

    ax1 = fig.add_subplot(3, 1, 1)
    for h in range(config.PRED_LEN):
        lw = 2.0 if h == 0 else 1.2
        ls_true = '-' if h == 0 else '--'
        ls_pred = '--' if h == 0 else ':'
        mk = 'o' if h == 0 else 's'
        label_sfx = f' t+{h+1}'

        ax1.plot(x, c_true[:, h], color=col_true, linestyle=ls_true, marker=mk,
                 markersize=6, linewidth=lw, label=f'True{label_sfx}', zorder=5)
        ax1.plot(x, c_fused[:, h], color=col_fused, linestyle=ls_pred, marker='s',
                 markersize=5, linewidth=lw, label=f'Fused{label_sfx}')
        ax1.plot(x, c_tm[:, h], color=col_tm, linestyle=ls_pred, marker='^',
                 markersize=5, linewidth=lw, label=f'{config.T_BRANCH_NAME}{label_sfx}')
        ax1.plot(x, c_gcn[:, h], color=col_gcn, linestyle=ls_pred, marker='v',
                 markersize=5, linewidth=lw, label=f'{config.G_BRANCH_NAME}{label_sfx}')
        ax1.plot(x, c_avg[:, h], color=col_avg, linestyle=ls_pred, marker='d',
                 markersize=5, linewidth=lw, label=f'Avg{label_sfx}')

    peak_month = crisis_info.get('peak_month', '')
    for xi, lbl in enumerate(c_labels):
        if lbl == peak_month or lbl.startswith(peak_month[:7]):
            ax1.axvline(x=xi, color='purple', linestyle='--', alpha=0.6, linewidth=1.5)
            ax1.annotate(f'Peak\n{lbl}', xy=(xi, ax1.get_ylim()[1]),
                         fontsize=8, color='purple', ha='center')
            break

    ax1.set_xticks(x)
    ax1.set_xticklabels(c_labels, rotation=45, ha='right', fontsize=9)
    ax1.set_xlabel('Month', fontsize=11)
    ax1.set_ylabel('Food Inflation Rate (%)', fontsize=11)
    ax1.set_title('Prediction vs. True Values During Crisis Period', fontsize=12, fontweight='bold')
    ax1.legend(loc='upper left', fontsize=8, ncol=5)
    ax1.grid(True, alpha=0.3)
    ax2 = fig.add_subplot(3, 1, 2)
    bar_width = 0.18
    for h in range(config.PRED_LEN):
        offset = h * (4 * bar_width + 0.05)
        label_sfx = f' t+{h+1}'
        ef = np.abs(c_fused[:, h] - c_true[:, h])
        et = np.abs(c_tm[:, h] - c_true[:, h])
        eg = np.abs(c_gcn[:, h] - c_true[:, h])
        ea = np.abs(c_avg[:, h] - c_true[:, h])
        alpha = 1.0 if h == 0 else 0.65
        ax2.bar(x + offset - 1.5 * bar_width, ef, bar_width, label=f'Fused{label_sfx}',
                color=col_fused, alpha=alpha)
        ax2.bar(x + offset - 0.5 * bar_width, et, bar_width, label=f'{config.T_BRANCH_NAME}{label_sfx}',
                color=col_tm, alpha=alpha)
        ax2.bar(x + offset + 0.5 * bar_width, eg, bar_width, label=f'{config.G_BRANCH_NAME}{label_sfx}',
                color=col_gcn, alpha=alpha)
        ax2.bar(x + offset + 1.5 * bar_width, ea, bar_width, label=f'Avg{label_sfx}',
                color=col_avg, alpha=alpha)

    ax2.set_xticks(x + (config.PRED_LEN - 1) * (4 * bar_width + 0.05) / 2)
    ax2.set_xticklabels(c_labels, rotation=45, ha='right', fontsize=9)
    ax2.set_xlabel('Month', fontsize=11)
    ax2.set_ylabel('Absolute Error (%)', fontsize=11)
    ax2.set_title('Absolute Error Comparison During Crisis Period', fontsize=12, fontweight='bold')
    ax2.legend(loc='upper right', fontsize=8, ncol=4)
    ax2.grid(True, alpha=0.3, axis='y')
    ax3 = fig.add_subplot(3, 1, 3)
    ax3.axis('off')

    def crisis_metrics(true, pred):
        mae = mean_absolute_error(true.flatten(), pred.flatten())
        rmse = np.sqrt(mean_squared_error(true.flatten(), pred.flatten()))
        r2 = r2_score(true.flatten(), pred.flatten())
        return mae, rmse, r2

    m_f = crisis_metrics(c_true, c_fused)
    m_t = crisis_metrics(c_true, c_tm)
    m_g = crisis_metrics(c_true, c_gcn)
    m_a = crisis_metrics(c_true, c_avg)

    table_data = [
        ['Fused (Selected)', f'{m_f[0]:.3f}', f'{m_f[1]:.3f}', f'{m_f[2]:.3f}'],
        [config.T_BRANCH_NAME, f'{m_t[0]:.3f}', f'{m_t[1]:.3f}', f'{m_t[2]:.3f}'],
        [config.G_BRANCH_NAME, f'{m_g[0]:.3f}', f'{m_g[1]:.3f}', f'{m_g[2]:.3f}'],
        ['SimpleAverage', f'{m_a[0]:.3f}', f'{m_a[1]:.3f}', f'{m_a[2]:.3f}'],
        ['—', '—', '—', '—'],
        [f'Crisis samples in test', f'{len(ci)}', f'Years: {crisis_years}', ''],
        [f'Peak Month', crisis_info["peak_month"], f'~{crisis_info["peak_value"]}%',
         crisis_info["crisis_label"][:30]],
    ]
    col_labels = ['Model / Info', 'MAE (%)', 'RMSE (%)', 'R²']

    table = ax3.table(cellText=table_data, colLabels=col_labels, loc='center', cellLoc='center')
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.3, 1.7)

    for j in range(len(col_labels)):
        c = table[(0, j)]
        c.set_facecolor('#B71C1C')
        c.set_text_props(color='white', fontweight='bold')
    row_colors = ['#FFEBEE', '#FCE4EC', '#F8BBD0', '#F48FB1']
    for i in range(1, 5):
        for j in range(len(col_labels)):
            table[(i, j)].set_facecolor(row_colors[i - 1])
    for j in range(len(col_labels)):
        table[(5, j)].set_facecolor('#EEEEEE')
    maes = [m_f[0], m_t[0], m_g[0], m_a[0]]
    best_row = np.argmin(maes) + 1
    table[(best_row, 1)].set_facecolor('#FFD700')

    ax3.set_title(f'Crisis Period Metrics ({", ".join(str(y) for y in crisis_years)})',
                  fontsize=11, fontweight='bold', pad=10)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    crisis_dir = _get_plots_dir(country, output_dir)
    fname = f"{_file_prefix(country)}_crisis_{'-'.join(str(y) for y in crisis_years)}.png"
    plt.savefig(os.path.join(crisis_dir, fname), dpi=180, bbox_inches='tight')
    plt.close()
    print(f"  ✓ Crisis analysis plot saved: {fname}")

def plot_full_timeline(df_clean: pd.DataFrame, results: dict, country: str,
                       output_dir: str, all_date_labels: list,
                       train_size: int, val_size: int):
    seq_len  = config.SEQ_LEN
    pred_len = config.PRED_LEN
    target_col = config.TARGET_COL

    if target_col not in df_clean.columns:
        return

    full_true   = df_clean[target_col].values.astype(float)
    full_labels = all_date_labels
    n_total     = len(full_true)
    n_test      = len(results["true_values"])
    train_boundary = train_size + seq_len
    val_boundary   = train_size + val_size + seq_len
    test_pred_start = val_boundary

    fig, axes = plt.subplots(pred_len, 1, figsize=(18, 5 * pred_len))
    if pred_len == 1:
        axes = [axes]

    x_full = np.arange(n_total)

    for h, ax in enumerate(axes):
        ax.axvspan(0,               train_boundary, alpha=0.07,
                   color='steelblue', label='Train period')
        ax.axvspan(train_boundary,  val_boundary,   alpha=0.07,
                   color='orange',    label='Val period')
        ax.axvspan(val_boundary,    n_total,        alpha=0.07,
                   color='limegreen', label='Test period')
        ax.plot(x_full, full_true, color='black', linewidth=1.2,
                label='True (all)', zorder=3)
        pred_row_start = test_pred_start + h
        pred_rows = list(range(pred_row_start, pred_row_start + n_test))
        valid = [(xi, yi) for xi, yi in zip(pred_rows, range(n_test)) if xi < n_total]
        if not valid:
            continue
        px = [v[0] for v in valid]
        pi = [v[1] for v in valid]

        fused_y = results["predictions"][pi, h]
        tm_y    = results["timemixer_predictions"][pi, h]
        gcn_y   = results["gcn_predictions"][pi, h]

        ax.plot(px, fused_y, color='red',         linewidth=1.8,
                linestyle='--', marker='o', markersize=3,
                label='Fused Prediction (test)', zorder=5)
        ax.plot(px, tm_y,    color='royalblue',   linewidth=1.2,
                linestyle=':', alpha=0.85, label=config.T_BRANCH_NAME)
        ax.plot(px, gcn_y,   color='forestgreen', linewidth=1.2,
                linestyle=':', alpha=0.85, label=config.G_BRANCH_NAME)
        _format_x_axis(ax, full_labels, max_ticks=22)

        ax.set_ylabel('Food Inflation Rate (%)', fontsize=11)
        ax.set_title(
            f'{country} — Full Timeline t+{h+1}  '
            f'(Test MAE={results["metrics"]["MAE"]:.3f}, '
            f'R²={results["metrics"]["R2"]:.3f})  |  Top{config.TOP_K_FEATURES}',
            fontsize=12, fontweight='bold')
        ax.legend(loc='upper left', fontsize=9, ncol=5)
        ax.grid(True, alpha=0.3)

    plt.tight_layout()
    save_dir = _get_plots_dir(country, output_dir)
    fname = f"{_file_prefix(country)}_full_timeline.png"
    plt.savefig(os.path.join(save_dir, fname), dpi=150, bbox_inches='tight')
    plt.close()

def main():
    output_dir = get_output_dir()
    feature_config_path = get_feature_config_path()
    feature_config_csv_path = get_feature_config_csv_path()
    k = config.TOP_K_FEATURES

    print("=" * 100)
    print(f"{config.T_BRANCH_NAME} (TimeMixer) + {config.G_BRANCH_NAME} (MV-CausalGCN)")
    print(f" Top-K = {k}")
    print("=" * 100)
    print(f"\nOutput directory: {output_dir}")
    print(f"Config: seq_len={config.SEQ_LEN}, pred_len={config.PRED_LEN}, "
          f"batch={config.BATCH_SIZE}, epochs={config.EPOCHS}, device={config.DEVICE}")
    print(f"   {config.G_BRANCH_NAME}: hidden={config.MVCGCN_HIDDEN_DIM}, "
          f"layers={config.MVCGCN_NUM_LAYERS}, lag={config.MVCGCN_CAUSAL_LAG}, "
          f"threshold={config.MVCGCN_GRAPH_THRESHOLD}")

    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(config.FILLED_DIR, exist_ok=True)

    print("\n" + "=" * 100)
    print(f"Phase 1: Feature Selection  (Top-{k})")
    print("=" * 100)

    csv_files = glob.glob(os.path.join(config.DATA_DIR, "*.csv"))
    print(f"Found {len(csv_files)} CSV files")

    feature_config = {}

    for i, path in enumerate(csv_files, 1):
        country = os.path.splitext(os.path.basename(path))[0]
        try:
            try:
                df = pd.read_csv(path, encoding="utf-8", engine="python")
            except Exception:
                df = pd.read_csv(path, encoding="gbk", engine="python")

            if config.TARGET_COL not in df.columns:
                continue

            df_clean = fill_and_clean_data(df, config.TARGET_COL)

            if len(df_clean) < config.SEQ_LEN + config.PRED_LEN + 10:
                continue
            _n_samples = len(df_clean) - config.SEQ_LEN - config.PRED_LEN + 1
            _test_size = min(max(int(0.2 * _n_samples), 2), _n_samples - 4)
            _val_size  = min(max(int(0.15 * _n_samples), 2), _n_samples - _test_size - 2)
            _train_size = _n_samples - _val_size - _test_size
            _train_end  = _train_size + config.SEQ_LEN + config.PRED_LEN - 1
            df_train_only = df_clean.iloc[:_train_end]

            selected_features, correlation_scores = select_top_k_features(
                df_train_only, config.TARGET_COL, k, config.EXCLUDE_COLS)

            feature_config[country] = {
                "selected_features": selected_features,
                "correlation_scores": {kk: float(v) for kk, v in correlation_scores.items()},
                "n_features": len(selected_features)
            }
        except Exception:
            continue

    save_feature_config(feature_config, feature_config_path)
    save_feature_config_csv(feature_config, feature_config_csv_path)
    print(f"✓ Feature selection done for {len(feature_config)} countries")

    print("\n" + "=" * 100)
    print(f"Phase 2: Model Training  (Top-{k})")
    print("=" * 100)

    summary = []
    attn_win_count = 0
    avg_win_count = 0

    for i, path in enumerate(csv_files, 1):
        country = os.path.splitext(os.path.basename(path))[0]
        if country not in feature_config:
            continue

        print(f"\n[{i}/{len(csv_files)}] {country}")
        print("-" * 80)

        try:
            try:
                df = pd.read_csv(path, encoding="utf-8", engine="python")
            except Exception:
                df = pd.read_csv(path, encoding="gbk", engine="python")
        except Exception as e:
            print(f"  Cannot read file: {e}")
            continue

        if config.TARGET_COL not in df.columns:
            continue
        all_date_labels_raw = extract_date_labels(df)

        df_clean = fill_and_clean_data(df, config.TARGET_COL)

        try:
            surviving = df_clean.index.tolist()
            all_date_labels = [
                all_date_labels_raw[i] if i < len(all_date_labels_raw) else str(i)
                for i in surviving
            ]
        except Exception:
            all_date_labels = all_date_labels_raw[:len(df_clean)]

        if len(all_date_labels) < len(df_clean):
            all_date_labels += [str(j) for j in range(len(all_date_labels), len(df_clean))]

        selected_features = feature_config[country]["selected_features"]

        try:
            train_data, val_data, test_data, scaler, feat_names, train_size, val_size = \
                prepare_data_with_selected_features(df_clean, selected_features,
                                                    config.SEQ_LEN, config.PRED_LEN)
        except Exception as e:
            print(f"  Skip (data prep): {e}")
            continue

        df_clean[selected_features].to_csv(
            os.path.join(config.FILLED_DIR, f"{country}.csv"),
            index=False, encoding="utf-8-sig")

        try:
            model, results = train_two_branch_hybrid(
                train_data, val_data, test_data, scaler, feat_names, country)
        except Exception as e:
            print(f" Training failed: {e}")
            import traceback
            traceback.print_exc()
            continue

        n_test_samples = len(results["true_values"])
        test_date_labels = get_test_date_labels(
            all_date_labels, train_size, val_size,
            config.SEQ_LEN, config.PRED_LEN, n_test_samples)

        metrics = results["metrics"]
        selected = results["selected_method"]
        if selected == "CrossAttention":
            attn_win_count += 1
        else:
            avg_win_count += 1

        pred_dir = os.path.join(output_dir, "predictions")
        os.makedirs(pred_dir, exist_ok=True)
        result_df = pd.DataFrame({
            'date': test_date_labels,
            **{f"true_t{h + 1}": results["true_values"][:, h] for h in range(config.PRED_LEN)},
            **{f"final_t{h + 1}": results["predictions"][:, h] for h in range(config.PRED_LEN)},
            **{f"cross_attn_t{h + 1}": results["attn_fused_predictions"][:, h] for h in range(config.PRED_LEN)},
            **{f"simple_avg_t{h + 1}": results["simple_avg_predictions"][:, h] for h in range(config.PRED_LEN)},
            **{f"tbranch_t{h + 1}": results["timemixer_predictions"][:, h] for h in range(config.PRED_LEN)},
            **{f"gbranch_t{h + 1}": results["gcn_predictions"][:, h] for h in range(config.PRED_LEN)},
        })
        pred_fname = f"{_file_prefix(country)}_predictions.csv"
        result_df.to_csv(os.path.join(pred_dir, pred_fname), index=False, encoding="utf-8-sig")

        plot_predictions(results, country, output_dir, test_date_labels)
        plot_last_n_detailed(results, country, output_dir, test_date_labels)
        plot_timeline_comparison(results, country, output_dir, test_date_labels)
        plot_two_branch_results(results, country, output_dir, test_date_labels)
        plot_fusion_comparison(results, country, output_dir, test_date_labels)
        plot_last_samples(results, country, output_dir, test_date_labels)
        plot_full_timeline(df_clean, results, country, output_dir,
                           all_date_labels, train_size, val_size)

        if country in config.CRISIS_COUNTRIES:
            print(f"Crisis country detected: {country}, generating crisis analysis plot...")
            plot_crisis_analysis(results, country, output_dir,
                                 test_date_labels, config.CRISIS_COUNTRIES[country])

        summary.append({
            "country": country,
            "selected_method": selected,
            "top_k": k,
            "MAE": metrics["MAE"], "MSE": metrics["MSE"],
            "RMSE": metrics["RMSE"], "R2": metrics["R2"],
            "MAE_CrossAttn": metrics["MAE_CrossAttn"], "MSE_CrossAttn": metrics["MSE_CrossAttn"],
            "RMSE_CrossAttn": metrics["RMSE_CrossAttn"], "R2_CrossAttn": metrics["R2_CrossAttn"],
            "MAE_SimpleAvg": metrics["MAE_SimpleAvg"], "MSE_SimpleAvg": metrics["MSE_SimpleAvg"],
            "RMSE_SimpleAvg": metrics["RMSE_SimpleAvg"], "R2_SimpleAvg": metrics["R2_SimpleAvg"],
            f"MAE_{config.T_BRANCH_NAME}": metrics["MAE_TimeMixer"],
            f"MSE_{config.T_BRANCH_NAME}": metrics["MSE_TimeMixer"],
            f"RMSE_{config.T_BRANCH_NAME}": metrics["RMSE_TimeMixer"],
            f"R2_{config.T_BRANCH_NAME}": metrics["R2_TimeMixer"],
            f"MAE_{config.G_BRANCH_NAME}": metrics["MAE_GCN"],
            f"MSE_{config.G_BRANCH_NAME}": metrics["MSE_GCN"],
            f"RMSE_{config.G_BRANCH_NAME}": metrics["RMSE_GCN"],
            f"R2_{config.G_BRANCH_NAME}": metrics["R2_GCN"],
            f"weight_{config.T_BRANCH_NAME}": metrics["weight_timemixer"],
            f"weight_{config.G_BRANCH_NAME}": metrics["weight_gcn"],
            "n_features": len(feat_names)
        })

        print(f"Final ({selected}): MAE={metrics['MAE']:.4f}, MSE={metrics['MSE']:.4f}, "
              f"RMSE={metrics['RMSE']:.4f}, R²={metrics['R2']:.4f}")
        print(f"    CrossAttention: MAE={metrics['MAE_CrossAttn']:.4f}, MSE={metrics['MSE_CrossAttn']:.4f}")
        print(f"    SimpleAverage:  MAE={metrics['MAE_SimpleAvg']:.4f}, MSE={metrics['MSE_SimpleAvg']:.4f}")
        print(f"    {config.T_BRANCH_NAME}: MAE={metrics['MAE_TimeMixer']:.4f}, "
              f"MSE={metrics['MSE_TimeMixer']:.4f}, R²={metrics['R2_TimeMixer']:.4f}")
        print(f"    {config.G_BRANCH_NAME}: MAE={metrics['MAE_GCN']:.4f}, "
              f"MSE={metrics['MSE_GCN']:.4f}, R²={metrics['R2_GCN']:.4f}")
        print(f"    Attn Weights: {config.T_BRANCH_NAME}={metrics['weight_timemixer']:.3f}, "
              f"{config.G_BRANCH_NAME}={metrics['weight_gcn']:.3f}")

    if summary:
        df_summary = pd.DataFrame(summary).sort_values("MAE")
        summary_fname = f"summary_top{k}_origscale_valfusion_fixfusion.csv"
        summary_path = os.path.join(output_dir, summary_fname)
        df_summary.to_csv(summary_path, index=False, encoding="utf-8-sig")

        total = len(summary)
        print("\n" + "=" * 100)
        print(f"Results Summary — Top-{k}  ({config.T_BRANCH_NAME} + {config.G_BRANCH_NAME})")
        print("=" * 100)
        print(f"\nFusion Method: CrossAttention={attn_win_count}/{total}, SimpleAverage={avg_win_count}/{total}")
        print("\nAverage Metrics:")
        print("-" * 90)
        print(f"{'Method':<20} {'MAE':>10} {'MSE':>10} {'RMSE':>10} {'R2':>10}")
        print("-" * 90)
        print(f"{'Final (Selected)':<20} "
              f"{df_summary['MAE'].mean():>10.4f} {df_summary['MSE'].mean():>10.4f} "
              f"{df_summary['RMSE'].mean():>10.4f} {df_summary['R2'].mean():>10.4f}")
        print(f"{'CrossAttention':<20} "
              f"{df_summary['MAE_CrossAttn'].mean():>10.4f} {df_summary['MSE_CrossAttn'].mean():>10.4f} "
              f"{df_summary['RMSE_CrossAttn'].mean():>10.4f} {df_summary['R2_CrossAttn'].mean():>10.4f}")
        print(f"{'SimpleAverage':<20} "
              f"{df_summary['MAE_SimpleAvg'].mean():>10.4f} {df_summary['MSE_SimpleAvg'].mean():>10.4f} "
              f"{df_summary['RMSE_SimpleAvg'].mean():>10.4f} {df_summary['R2_SimpleAvg'].mean():>10.4f}")
        tb = config.T_BRANCH_NAME
        gb = config.G_BRANCH_NAME
        print(f"{tb:<20} "
              f"{df_summary[f'MAE_{tb}'].mean():>10.4f} {df_summary[f'MSE_{tb}'].mean():>10.4f} "
              f"{df_summary[f'RMSE_{tb}'].mean():>10.4f} {df_summary[f'R2_{tb}'].mean():>10.4f}")
        print(f"{gb:<20} "
              f"{df_summary[f'MAE_{gb}'].mean():>10.4f} {df_summary[f'MSE_{gb}'].mean():>10.4f} "
              f"{df_summary[f'RMSE_{gb}'].mean():>10.4f} {df_summary[f'R2_{gb}'].mean():>10.4f}")
        print("-" * 90)
        print(f"\n Avg Weights: {tb}={df_summary[f'weight_{tb}'].mean():.3f}, "
              f"{gb}={df_summary[f'weight_{gb}'].mean():.3f}")
        print(f"\nSummary saved: {summary_path}")
        print("=" * 100)
    else:
        print("\nNo successful cases")


if __name__ == "__main__":
    import gc

    for k_val in config.TOP_K_LIST:
        set_seed(config.SEED)
        config.TOP_K_FEATURES = k_val
        print("\n" + "#" * 80)
        print(f"{get_output_dir()} ##".center(80))
        print("#" * 80)

        try:
            main()

            print(f"\n[SUCCESS] K={k_val} ")

        except Exception as e:
            print(f"\n[ERROR] K={k_val} {e}")
            import traceback

            traceback.print_exc()
            continue

        finally:
            plt.close('all')
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    print("\n" + "=" * 80)
    print("finish".center(80))
    print("=" * 80)